import { Component } from '@angular/core';

@Component({
  selector: 'app-profile-menu-mobile',
  templateUrl: './profile-menu-mobile.component.html',
  styleUrls: ['./profile-menu-mobile.component.scss']
})
export class ProfileMenuMobileComponent {

}
