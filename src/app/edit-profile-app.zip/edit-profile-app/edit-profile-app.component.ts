import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-profile-app',
  templateUrl: './edit-profile-app.component.html',
  styleUrls: ['./edit-profile-app.component.scss']
})
export class EditProfileAppComponent {

}
